document.getElementById('about-heading').addEventListener('click', function() {
    alert('You clicked on the About the Pocket Watch heading!');
});